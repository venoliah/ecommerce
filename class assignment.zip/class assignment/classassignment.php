<html>
    <head>
        <title>Sum of two numbers</title>
    </head>
    <body>
        <h1>Sumation Of Numbers</h1>
        <form action="calculate_sum.php" method="post">
            <label for="First_Number">Enter the first Number:</label>
            <input type="number" id="First_Number" name="First_Number" value="" step="2"><br><br>
            <label for="Second_Number">Enter the second Number :</label>
            <input type="number" id="Second_Number" name="Second_Number" value="" step="2"><br><br>
            <input type="submit" value="SUBMIT">
        </form>
    </body>
</html>