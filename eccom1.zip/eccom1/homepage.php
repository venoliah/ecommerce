<html>
    <head>
        <link rel="stylesheet" href="eccomerce.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <title> Home page </title>

       

        </head>
        <body>

           <!-- <p>This is an official link to <a href=" orders/orders.html"> make orders</a></p>
            <p> This is an official link to <a href="contacts.html"> access the contacts list</a> </p>
            <p>This is a link to <a href="contacts.html#lmao"> lmao</a> </p>-->

            

           <ul>
                
                <li><a href="#About" target="_blank">About</a></li>
                <li><a href="login.php">Login</a></li>
                <li> <a href="adminlogin.php">Admin</a></li>
                <li><a href="#Help" target="_blank">Help</a></li>
                <a href="#" class="icons icons-cart"><ion-icon name="cart-outline"></ion-icon></a> 

            </ul>

            <h1 ><i>Beuthful </i><br><span class="index"><dd >thrift- shop</dd></span></h1>
            <div class="background">

       <div class="subtitle"> <span >BE YOU,</span><br> <span> BE YOUTHFUL,</span><br><span> BE BEAUTIFUL</span></div><br><br><br>
<p class="contectsubheading">A virtually reliable shop that offers you diverse items<br>  worth your while at a fairly affordable price and from the comfort of you home.</p><br>
<p>Let us help you help us. <br> We do not just dress to make a statement. <br>DRESS TO KILL!!</p>
<p>Already have an account??</p><br><br>
<a href="registration.php" class="register" target="_blank">REGISTER NOW</a>


</div><br><hr>

<!--<img src="https://i.pinimg.com/236x/42/9d/83/429d835118cd579aa6388f41c292e13c.jpg" width="200" height="200" ><hr>-->


<h3>SPEND LESS $$ GAIN MORE</h3>
<br>

<p >Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima aspernatur facilis odio ab, ullam laborum.<br> Error quia, ab dolore nihil molestias repellat tempore quisquam, eaque in sint aut repudiandae quam!\</p>
<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Unde perferendis numquam tempore velit eveniet fuga,<br> reiciendis voluptate placeat architecto! Vero doloribus cupiditate, rerum ea expedita assumenda cumque voluptate minus quam.</p>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quisquam voluptates dolor aut ut voluptatibus reprehenderit illum sit?<br> Vero at officiis quisquam non totam neque quidem veritatis error, nam earum?</p>
<br><br>
<img src="https://i.pinimg.com/564x/7b/5f/4d/7b5f4d70fc98c7e44b1416e9ae537471.jpg" width="400" height="400">
<img src="https://i.pinimg.com/564x/cd/41/9f/cd419f583da44604ca30e3c6b00e862a.jpg" width="400" height="400">
<img src="https://i.pinimg.com/236x/14/af/82/14af820c74be16774c6e20139e460b1a.jpg" width="400" height="400"><br><br>
<img src="https://i.pinimg.com/236x/8b/94/a7/8b94a7b1a3c657117987cbf479191d30.jpg" width="400" height="400">
<img src="https://i.pinimg.com/236x/60/99/95/6099958257d7c1556b9033eb187f1b1f.jpg" width="400" height="400" >
<img src="https://i.pinimg.com/236x/1b/59/07/1b59079e8c5be6637cda8622e4644495.jpg" width="400" height="400" alt="">

<br><br><hr>
<h3>A Shopper's first choice</h3>

<p>Below are a few of our shopper's who have benefited from our services and have lived to tell the story.<br>Don't just live the tale 
and hear the stories,join us and live the fairytale!!</p>

<div class="testimonials">
<img src="https://i.pinimg.com/564x/b0/73/10/b07310843457b731bcdeb0b0f215351d.jpg" width="300" height="300" >
<img src="https://i.pinimg.com/236x/ad/01/dd/ad01dd422272e63bdbdac48a081a1ed5.jpg" width="300" height="300" >
<img src="https://i.pinimg.com/236x/4b/3f/f1/4b3ff152fc26c0239301be5952396b77.jpg" width="300" height="300" >

</div>

<p>Be a part of our <span>FAMILY</span> today <br> COME ONE!! COME ALL!!</p>

<br><br>

<h3><span> Creating a fun $ favourable $hopping experience</span></h3>
<!--Here just add some social media icons-->
<br><br>
<div class="radio">
<td>
    <input type="radio" class="Make_money_with_us" name="box2"> 
    <label> Make money with us</label>
    <input type="radio" class="support" name="box2"> 
    <label> support</label><br><br>
    <input type="radio" class="contact_us" name="box2"> contact us
        <input type="radio" class="make_a_complaint" name="box2"> make a complaint<br><br>
    <input type="radio" class="policy" name="box2"> policy
    <input type="radio" class="refferals" name="box2"> Refferals
</td></tr>

  </div>
<br><br><br><br>


<a href="https://web.whatsapp.com/" class="icons icons-whatsapp" target="_blank"><ion-icon name="logo-whatsapp"></ion-icon></a> 
<a href="https://www.facebook.com/" class="icons icons-facebook" target="_blank"><ion-icon name="logo-facebook"></ion-icon></a>
<a href="https://www.paypal.com/us/signin" class="icons icons-paypal" target="_blank"><ion-icon name="logo-paypal"></ion-icon></a>
<a href="https://www.paypal.com/us/signin" class="icons icons-twitter" target="_blank"><ion-icon name="logo-twitter"></ion-icon></a>
<a href="https://www.instagram.com/?hl=en" class="icons icons-instagram" target="_blank"><ion-icon name="logo-instagram"></ion-icon></a>
<a href="https://www.google.com/aclk?sa=l&ai=DChcSEwj47ZiBsen3AhUa-VEKHQcwB9wYABAAGgJ3cw&sig=AOD64_2Z1XFp2m4rpnX8HYA_OrKCw5m-Mw&q&adurl&ved=2ahUKEwj92JCBsen3AhXphv0HHXtIBQwQ0Qx6BAgEEAE" class="icons icons-bolt" target="_blank"><ion-icon name="bicycle-outline"></ion-icon></a>
<br><br><br><br>

<div class="mapouter"><div class="gmap_canvas"><iframe width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=uhuru%20market,nairobi&t=&z=17&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.embedgooglemap.net/blog/divi-discount-code-elegant-themes-coupon/"></a><br><style>.mapouter{position:right;text-align:right;height:800px;width:1000px;}</style><a href="https://www.embedgooglemap.net">embedgooglemap.net</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:700px;width:1000px;}</style></div></div>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

   
