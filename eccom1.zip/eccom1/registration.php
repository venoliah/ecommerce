<html>
    <head>
        <link rel="stylesheet" href="registration_login.css">

        <title>SIGN-UP PAGE</title>
    </head>
    <body>
    <ul>
                
                <li><a href="#About" target="_blank">About</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="#Help" target="_blank">Help</a></li>
                <a href="#" class="icons icons-cart"><ion-icon name="cart-outline"></ion-icon></a> 

            </ul>
        <h1 ><i>Beu- th- ful </i><br><span class="index"><dd >thrift- shop</dd></span></h1>
        <br><br>
        <div class="form">

        <form action="process_register.php" method="post">
        <label for="reg_number">Registration_Number:</label>
            <input type="number" id="reg_number" name="reg_number" value=""><br><br>
         
            <label for="First_Name">First_Name:</label>
            <input type="text" id="First_Name" name="First_Name" value=""><br><br>
            <label for="Surname">Surname:</label>
            <input type="text" id="Surname" name="Surname" value=""><br><br>
            <tr>
                <td>
                  Phone_Number:  
                </td>
                <td>
                    <select>
                        <option>254</option>
                        <option>455</option>
                        <option>657</option>
                        <option>879</option>
                        <option>345</option>
                        <option>984</option>
                        <option>335</option>
                        <option>875</option>
                        <option>276</option>
                    </select>
                <input type="Phone" placeholder="7406783******" name="Phone_Number"></td>
            </tr>
            <br><br>
            <label for="Email">Email:</label>
            <input type="email" id="Email" name="Email" value=""><br><br>
            <label for="User_Name">User-Name:</label>
            <input type="text" id="User_Name" name="User_Name" value=""><br><br>
            <label for="Password">Password:</label>
            <input type="password" id="Password" name="Password" value=""><br><br>
            <label for="Confirm_Password">Confirm_Password:</label>
            <input type="password" id=" Confirm_Password" name="Confirm_Password" value=""><br><br>
            <label for="Sex">Sex:</label>
            <input type="checkbox" id="Male" name="Gender" value="Male">
            <label for="Male">Male</label>
            <input type="checkbox"  id="Female" name="Gender" value="Female">
            <label for="Female">Female</label>
            <input type="checkbox" id="Non-Binary" name="Gender" value="Non-binary">
            <label for="Non-Binary" >Non-Binary</label>
            <br><br>

            <input type="submit" value="SUBMIT">
        </div>
        </form>

        
<br><br><br>
        
<a href="https://web.whatsapp.com/" class="icons icons-whatsapp" target="_blank"><ion-icon name="logo-whatsapp"></ion-icon></a> 
<a href="https://www.facebook.com/" class="icons icons-facebook" target="_blank"><ion-icon name="logo-facebook"></ion-icon></a>
<a href="https://www.paypal.com/us/signin" class="icons icons-paypal" target="_blank"><ion-icon name="logo-paypal"></ion-icon></a>
<a href="https://www.paypal.com/us/signin" class="icons icons-twitter" target="_blank"><ion-icon name="logo-twitter"></ion-icon></a>
<a href="https://www.instagram.com/?hl=en" class="icons icons-instagram" target="_blank"><ion-icon name="logo-instagram"></ion-icon></a>
<a href="https://www.google.com/aclk?sa=l&ai=DChcSEwj47ZiBsen3AhUa-VEKHQcwB9wYABAAGgJ3cw&sig=AOD64_2Z1XFp2m4rpnX8HYA_OrKCw5m-Mw&q&adurl&ved=2ahUKEwj92JCBsen3AhXphv0HHXtIBQwQ0Qx6BAgEEAE" class="icons icons-bolt" target="_blank"><ion-icon name="bicycle-outline"></ion-icon></a>
<br><br><br><br>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </body>
</html>